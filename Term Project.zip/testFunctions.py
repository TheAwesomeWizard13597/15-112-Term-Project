import numpy as np
from helpfulFunctions import *
from arrowCode import *
import PIL.Image
from cmu_112_graphics import *

def keyPressed(app, event):
    print(event.key)

